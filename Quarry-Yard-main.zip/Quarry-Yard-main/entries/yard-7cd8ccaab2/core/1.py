def buscar_negocios_entorno(lat_centro, lon_centro, api_key, radio_metros=500):
    # ... [omitido: docstring con dominio y referencia a un fichero de negocio del proyecto origen] ...
    url = "https://places.googleapis.com/v1/places:searchNearby"
    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": api_key,
        "X-Goog-FieldMask": "places.id,places.displayName,places.location,places.formattedAddress"
    }

    payload = {
        "locationRestriction": {
            "circle": {
                "center": {"latitude": lat_centro, "longitude": lon_centro},
                "radius": radio_metros
            }
        },
        # En searchNearby es obligatorio incluir al menos un tipo.
        # ... [omitido: comentario que referencia un fichero de negocio del proyecto origen] ...
        "includedPrimaryTypes": [
            "clothing_store", "supermarket", "bank", "department_store", "shopping_mall"
        ],
        "languageCode": "es"
    }

    response = requests.post(url, headers=headers, json=payload)
    if not response.ok:
        raise RuntimeError(f"Places API Nearby ({response.status_code}): {response.text}")
    return response.json().get("places", [])


def buscar_lugares_text_circular(lat, lon, query, api_key,
                                 radio_metros=1500, top_k=2):
    """Busca lugares por texto con sesgo circular (sin restricción dura).

    Usa el endpoint Places API (New) `searchText` con `locationBias.circle`,
    que prioriza los resultados dentro del círculo pero NO los limita
    estrictamente. Pensado para encontrar anclajes del casco urbano (plaza,
    ayuntamiento, iglesia) alrededor de una candidata en modo "ciudad
    pequeña".

    Args:
        lat: latitud del centro del círculo.
        lon: longitud del centro del círculo.
        query: texto de búsqueda (p. ej. "plaza").
        api_key: clave de Google Places API.
        radio_metros: radio del círculo de sesgo. Default 1500.
        top_k: número máximo de resultados a devolver. Default 2.

    Returns:
        Lista (recortada a `top_k`) de dicts con claves `place_id`,
        `nombre`, `latitud`, `longitud`.

    Raises:
        RuntimeError: si la llamada a la Places API falla.
    """
    url = "https://places.googleapis.com/v1/places:searchText"
    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": api_key,
        "X-Goog-FieldMask": "places.id,places.displayName,places.location",
    }

    payload = {
        "textQuery": query,
        "languageCode": "es",
        "locationBias": {
            "circle": {
                "center": {"latitude": lat, "longitude": lon},
                "radius": radio_metros,
            }
        },
        "maxResultCount": top_k,
    }

    response = requests.post(url, headers=headers, json=payload)
    if not response.ok:
        raise RuntimeError(
            f"Places API searchText circular ({response.status_code}): "
            f"{response.text[:200]}"
        )

    places = response.json().get("places", [])[:top_k]
    return [
        {
            "place_id": p.get("id"),
            "nombre": (p.get("displayName") or {}).get("text"),
            "latitud": (p.get("location") or {}).get("latitude"),
            "longitud": (p.get("location") or {}).get("longitude"),
        }
        for p in places
    ]